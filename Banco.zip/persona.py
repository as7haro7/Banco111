class Persona:
    def __init__(self, codigo_cliente, nombres, apellidos, cedula, direccion, referencia):
        self.codigo_cliente = codigo_cliente
        self.nombres = nombres
        self.apellidos = apellidos
        self.cedula = cedula
        self.direccion = direccion
        self.referencia = referencia


class Cuenta:
    def __init__(self, codigo_cuenta, codigo_cliente, saldo):
        self.codigo_cuenta = codigo_cuenta
        self.codigo_cliente = codigo_cliente
        self.saldo = saldo
